%read (soil moisture and soil temperature) data from .asc:
FN = 'meteoairsol_1a_Lz1NsolF1minPtuPflux_v01_20160701_000000_1440.asc'; 
delimiterIn = ' '; 
headerlinesIn = 30;
A = importdata(FN,delimiterIn,headerlinesIn);

%header, and first column (=time stamps):
A.textdata

%the 'relevant' columns (wind speed, wind direction):
A.data

%plot:
plot(A.data(:,1)),
