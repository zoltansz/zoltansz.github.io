%read (ground weather) data from .asc:
FN = 'meteoairsol_1a_Lz1NairF1minPtuvPrain_v01_20160701_000000_1440.asc'; 
delimiterIn = ' '; 
headerlinesIn = 19;
A = importdata(FN,delimiterIn,headerlinesIn);

%header, and first column (=time stamps):
A.textdata

%the 'relevant' columns (wind speed, wind direction):
A.data

%plot:
plot(A.data(:,1)),