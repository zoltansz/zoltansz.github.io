%clear start:
    clear all;
    close all;

% parameters:
    d = 5;
    patch_size = 10;

%read the image, resize so that it could be partioned to 
% 'patch_size x patch_size'-sized parts:    
I = imread('image.jpg'); % 399   600     3
I = imresize(I, [400 600], 'bicubic');

%rgb -> gray, int -> double.
I = double(rgb2gray(I)) / 255;
figure; imshow(I,[]); title('Original image');

%extract patches:
X = im2col(I, [patch_size, patch_size], 'distinct');

%centering (remove mean):
m = mean(X,2);
M = repmat(m,1,size(X,2));
X = X - M;

%cov(X) => eigenvalues, eigenvectors:
C = cov(X');
[V,D] = eig(C);
D = diag(D);
%plot(D);

%rearrange eigenvalues/eigenvectors to decreasing order 
%[we got them in increasing order from 'eig']:
V = fliplr(V);
D = flipud(D);
figure; plot(D); title('eigenvalues');
figure; plot(cumsum(D)/sum(D)); title('energy preserved');


%approximation using d principal components:
X_hat = V(:,1:d) * V(:,1:d)' * X + M;
I_hat = col2im(X_hat, [patch_size, patch_size], size(I), 'distinct');

%show the approximation:
figure; imshow(I_hat,[]); title(strcat(['Image comressed using ',num2str(d), ' PCs.']));
