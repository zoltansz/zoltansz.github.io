OSDL (Online Group-Structured Dictionary Learning) Matlab package.

AUTHOR:
The code is written by Zoltan Szabo ("http://nipg.inf.elte.hu/szzoli").

CONTACT:
In case of any question, comment, idea or bug report you can contact me at "szzoli (at) cs.elte.hu".

AFFILIATION:
Eotvos Lorand University, Faculty of Informatics, Pazmany Peter setany 1/C, Budapest, H-1117, Hungary.

DESCRIPTION:
The Matlab source code provides a template for the OSDL method described in

@INPROCEEDINGS{szabo11online,
  AUTHOR =       {Zolt{\'a}n Szab{\'o} and Barnab{\'a}s P{\'o}czos and Andr{\'a}s L{\H{o}}rincz},
  TITLE =        {Online Group-Structured Dictionary Learning},
  BOOKTITLE =    {IEEE Computer Vision and Pattern Recognition (CVPR)},
  YEAR =         {2011},
  pages =        {2865-2872},
  address =      {Colorado Springs, CO, USA},
  month =        "20-25~"#jun,
}

OSDL is a dictionary learning approach, which:
1)is online,
2)enables overlapping group structures with
3)non-convex group-structure inducing, and
4)handles the partially observable case.
Moreover,
i)the columns of the dictionary can belong to a closed, convex and bounded set, and
ii)the hidden representation can be restricted to a closed, convex set.

INSTALLATION:
1)Extract the .rar/.zip/.tar file and add the result to your Matlab PATH.
2)Download the ICA natural image dataset from "http://research.ics.tkk.fi/ica/data/images/" (1.tiff,2.tiff,...,13.tiff). Add the images also to the Matlab PATH.
This dataset will form the observation of the OSDL method.
3)Transform the ICA dataset to OSDL observations: "generate_X.m".
4)Optimize dictionary by the OSDL technique: "demo_OSDL_D_optimization.m".
5)Inpainting illustration using the obtained dictionary: "demo_OSDL_inpainting.m". 

RELEASE:
v1.1 (August 23rd, 2011): v1.0 + BCD optimization.
v1.0 (June 15th, 2011)  : BCDA optimization, inpainting.

LICENSE:
OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or (at your option) any later version.