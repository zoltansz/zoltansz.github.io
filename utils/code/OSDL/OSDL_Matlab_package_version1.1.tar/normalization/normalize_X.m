function [X] = normalize_X(X)
%Patch normalization to zero mean and unit l_2 norm.
%
%Argument:
%   X(:,t): t^th patch in vector form
%
%Output:
%   X: normalized image
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

%zero mean (x -> x - 1/n * sum_{i=1}^n} x_i):
    m = mean(X,1);
    X = X - repmat(m,[size(X,1) 1]);
    
%unit l_2 norm (x -> x/||x||_2):
    norm_X = sqrt(sum(X.^2,1));
    idxs = find(norm_X~=0);
    X = X(:,idxs);
    X = X ./ repmat(norm_X(idxs),[size(X,1) 1]);