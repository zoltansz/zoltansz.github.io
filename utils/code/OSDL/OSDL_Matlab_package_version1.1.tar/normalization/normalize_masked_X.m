function [X,m,norm_X,idxs] = normalize_masked_X(X,M)
%Patch normalization to zero mean and unit l_2 norm, using the available (determined by mask M) coordinates.
%
%Argument:
%   X(:,t): t^th patch in vector form
%   M: mask for the observable coordinates of X, "M(i,j)=1" = "X(i,j) is not observable", "M(i,j)=0" = "otherwise".
%
%Output:
%   X: normalized X.
%   m, norm_X, idx: describe the normalizing transformation.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

T = size(X,2);

%zero mean:
    m = zeros(1,T);
    for t = 1 : T
        if sum(~M(:,t))==0%no measured quantities
            m(t) = 0;
        else
            m(t) = mean(X(~M(:,t),t));
        end
    end
    X = X - repmat(m,[size(X,1) 1]);
    
%unit l_2 norm:
    norm_X = zeros(1,T);
    for t = 1 : T
        if sum(~M(:,t))==0%no measured quantities
            norm_X(t) = 1;
        else
            norm_X(t) = sqrt(sum(X(~M(:,t),t).^2));
        end
    end
    idxs = find(norm_X~=0);
    X(:,idxs) = X(:,idxs) ./ repmat(norm_X(idxs),[size(X,1) 1]);
