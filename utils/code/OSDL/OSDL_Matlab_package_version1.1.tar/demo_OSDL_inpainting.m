%function [] = demo_OSDL_inpainting()
%OSDL (Online Group-Structured Dictionary Learning) demonstration and template for inpainting with the obtained dictionary.
%Run demo_OSDL_D_optimization.m first to have a D dictionary.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

%clear start:
    clear all; close all;
    
%parameters:
    %size of image patches:
        dim_x_1 = 8;
        dim_x_2 = 8;        
    dim_x = dim_x_1 * dim_x_2;
    eta = 0.5; %\in (0,2); regularization with || ||_eta: Omega(alpha) = || (||alpha_G||_2)_G ||_eta; in case of eta \in (0,1]: the closer eta is to 0, the more 'aggressive' the sparsifications is
    kappa = 1/2^13; %>0, approximation-regularization tradeoff, the smaller kappa is the less the group structure is enforced.
    %G (group structure):
        %toroid:
            G_type = 'toroid';
            G_params.dim_alfa_y = 16;
            G_params.dim_alfa_x = 16;
            G_params.neighbor_size = 2; %Example: kappa = 1/2^13
    epsi = 1e-5; %smoothing constant of z to insure numerical stability, positive, <<1 
    num_of_zalfa_its = 5; %number of (z,alfa) iterations
    %constraints for alfa:
        constraint_alfa_id = 0; %"0" = "no constraint", "1" = "non-negativity"
    k = 11; %id of the test image in the full inpainting illustration
    inpainting_method = 'sliding'; %'distinct', or 'sliding' (=used in the CVPR paper)
    p_missing_test = 0.3;% 0.3x100=30% of the pixels are missing from the test image
    epoch = 1; %to 'FN_suffix_train'

%define the group structure (children, parents):
    [children_ct,parents_ct,children_uniform,parents_uniform,dim_alfa] = generate_group_structure_G(G_type,G_params); %children xor children_ct,parents xor parents_ct
    
%load test image I and a dictionary D:
    I = double(imread([num2str(k), '.tiff']))/255;    
    FN_suffix_train = strcat('epoch',num2str(epoch),'.mat');
    FN  = strcat('summary','_',FN_suffix_train);
    load(FN,'D');
     
%extract the dim_x_1 x dim_x_2 sized patches of the test image:
    X = im2col(I,[dim_x_1 dim_x_2],inpainting_method);
    
%mask to remove coordinates from the observation:
    M0 = (rand(size(I)) < p_missing_test);
    M = im2col(M0,[dim_x_1 dim_x_2],inpainting_method);
    
%normalize X using its observable coordinates:
    [X_normalized, mean_X,norm_X,idxs] = normalize_masked_X(X,M);
    
%estimate the unknown coordinates of X:
    X_hat_normalized = inpaint_with_D(X_normalized,M,D,children_ct,parents_ct,children_uniform,parents_uniform,dim_alfa,eta,kappa,epsi,num_of_zalfa_its,constraint_alfa_id);
    
%denormalize the estimation using 'mean_X','norm_X' and 'idxs':  
    X_hat = X_hat_normalized;
    X_hat(:,idxs) = X_hat(:,idxs) .* repmat(norm_X(idxs),[size(X_hat_normalized,1) 1]);
    X_hat = X_hat + repmat(mean_X,[size(X_hat_normalized,1) 1]); 
    
%in case of 'sliding', average the estimated patches at each pixel:
    if strcmp(inpainting_method,'sliding')
        X_hat = im2col_average(X_hat,dim_x_1,dim_x_2,size(I,1),size(I,2)); 
    end
    
%plot the result:    
    figure;
        subplot(3,1,1); 
            imshow(I,[]); 
            title('Original image: without corruption');
        subplot(3,1,2); 
            imshow(I.*(1-M0),[]); 
            title('Original image: corrupted');
        subplot(3,1,3);  
            if strcmp(inpainting_method,'distinct')
                plot_D_toroid(X_hat,size(I,1)/dim_x_1,size(I,2)/dim_x_2,dim_x_1,dim_x_2,0,0); %"0","0":offset,size_of_edge,
            else
                imshow(X_hat,[]);
            end
            title(strcat(['Estimation using the OSDL dictionary with "',inpainting_method,'" windows']));
