function [] = generate_X()
%Transforms the ICA natural image dataset to OSDL observations.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

%parameters:
    %database:
        %size of the training image patches:
            dim_x_1 = 8;
            dim_x_2 = 8;
        p_missing_train = 0.1;%0.1x100 = 10% of the coordinates (=pixels) are missing
        image_indices = [1:10,12:13];%indices of the natural images used for D optimization
    %D optimization:
        num_of_mini_batches = 512; %number of mini-batches
        size_of_mini_batches = 64;  %size of the mini-batches
        num_of_samples = num_of_mini_batches * size_of_mini_batches; %number of samples used for D optimization, in one epoch
        epoch_interval = [1]; %D can be optimized in multiple epochs, for a single epoch use "[1]", for five epochs use "[1:5]".
    
generate_X_step1(dim_x_1,dim_x_2,image_indices);
generate_X_step2(dim_x_1,dim_x_2,num_of_samples,epoch_interval,image_indices,p_missing_train);