function [] = generate_X_step2(dim_x_1,dim_x_2,num_of_samples,epoch_interval,image_indices,p_missing_train)
%Randomly samples the image patches created by 'generate_X_step1.m' without replacement and removes 'p_missing_trainx100' percent of their pixels.
%The result is saved  to 'training_samples... .mat' (X) and 'mask... .mat' (M = positions of the corruptions).
%Mask is generated only if p_missing_train > 0.
%
%Arguments:
%   dim_x_1,dim_x_2: size of the training image patches.
%   num_of_samples : number of training samples used for D optimization, in one epoch.
%   epoch_interval : one can generate training samples for multiple epochs, e.g., for (the first) five epochs of D optimizaton "epoch_interval=[1:5]".
%   image_indices  : indices of the natural images used for D optimization, elements \in {1,...,13}.
%   p_missing_train: \in [0,1), p_missing_train x100 percent of the coordinates (=pixels) are missing of the training samples.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

%initialization:    
    num_of_ks = length(image_indices);
    dim_x = dim_x_1 * dim_x_2;
    per1 = floor(num_of_samples/num_of_ks);
    d_t = ones(num_of_ks,1) * per1;
    d_t(end) = num_of_samples - per1*(num_of_ks-1);
    cumsum_d_t  = cumsum(d_t);
    
for epoch = epoch_interval
    %X:
        X = zeros(dim_x,num_of_samples);    
        pX = randperm(num_of_samples);
        for nk = 1 : num_of_ks
            k = image_indices(nk);
            %load Xk:
                FN = strcat('patches_in_image_',num2str(k),'_dimx_',num2str(dim_x_1),'x',num2str(dim_x_2),'.mat');                
                load(FN,'Xk');
            %X(:,...) = Xk:
                p = randperm(size(Xk,2));
                X(:,pX(cumsum_d_t(nk)-d_t(nk)+1:cumsum_d_t(nk)))= Xk(:,p(1:d_t(nk)));
            disp(strcat(['For epoch ',num2str(epoch),' image ',num2str(k),' is sampled.']));
        end
    %save X:
        FN = strcat('training_samples','_dimx_',num2str(dim_x_1),'x',num2str(dim_x_2),'_T',num2str(num_of_samples),'_epoch',num2str(epoch),'.mat');
        save(FN,'X');
    %indices of the not observed coordinates = 'mask':
        M = (rand(dim_x,num_of_samples)< p_missing_train);%"1" = "missing", "0" = "not missing"
    %save 'mask':
        if p_missing_train > 0
            FN = strcat('mask','_dimx_',num2str(dim_x_1),'x',num2str(dim_x_2),'_T',num2str(num_of_samples),'_epoch',num2str(epoch),'_pm',num2str(p_missing_train),'.mat');
            save(FN,'M');
        end
end