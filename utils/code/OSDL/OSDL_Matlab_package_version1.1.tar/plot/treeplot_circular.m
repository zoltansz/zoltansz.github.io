function treeplot_circular(p)
%Circular treeplot display of a tree with nodes given in p. Node definition (p) follow the same scheme as treeplot.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

[x,y,h] = treelayout(p);

%%%%%%%%%%%%%%%%%%%%%%%%
%Use polar coordinates %
%%%%%%%%%%%%%%%%%%%%%%%%
r = max(y)-y;
alpha = 2*pi*x;
x = r.*cos(alpha);
y = r.*sin(alpha);
%%%%%%%%%%%%%%%%%%%%%%%%

f = find(p~=0);
pp = p(f);
X = [x(f); x(pp); repmat(NaN,size(f))];
Y = [y(f); y(pp); repmat(NaN,size(f))];
X = X(:);
Y = Y(:);

n = length(p);
plot (x, y, 'ko', X, Y, 'k-','Linewidth',3);
