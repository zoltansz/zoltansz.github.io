function [D2] = plot_D_toroid(D,dim_alfa_y,dim_alfa_x,dim_x_1,dim_x_2,offset,size_of_edge)
%Illustrates dictionary D in case of toroid group structure.
%
%Arguments:
%   D: dictionary,
%   size of the toroid: dim_alfa_y x dim_alfa_x,
%   size of the d_j columns of D: dim_x_1 x dim_x_2,
%   offset: shift every second row with the value of this variable; can be used for 'toroid' imitation, see 'plot_D.m'
%   size_of_edge: separate d_js; =width of separation.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

%parameters:
    scale_factor = min(min(D)); %"0", "1/2","min(min(D))"; has effect only in case of size_of_edge > 0
    
%initialize the "background" of D:
    D2 = scale_factor * ones(size_of_edge+(size_of_edge+dim_x_1)*dim_alfa_y,offset+size_of_edge+(size_of_edge+dim_x_2)*dim_alfa_x);
    
n = 0;
for k2 = 1 : dim_alfa_x
for k1 = 1 : dim_alfa_y        
        n = n + 1;
        iy2 = (size_of_edge+dim_x_1)*k1;
        iy1 = iy2-(dim_x_1-1);
        
        ix2 = (size_of_edge+dim_x_2)*k2;
        ix1 = ix2-(dim_x_2-1);
        if mod(k1,2)==1
            ix2 = ix2 + offset;
            ix1 = ix1 + offset;
        end
        D2(iy1:iy2,ix1:ix2) = reshape(D(:,n),[dim_x_1,dim_x_2]);
    end
end

imshow(D2,[]);
