function [fig_handle] = plot_D_treeplot(D,dim_x_1,dim_x_2,max_level)
%Circular display of a full binary tree structured dictionary (D), having elements of size 'dim_x_1' x 'dim_x_2', restricting the plot to 'max_level' number of levels.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

%parents:
    tmpvec = 1:(2^(max_level-1)-1);
    parents = [0,kron(tmpvec, [1 1])];
    %parents = [0 1 1 2 2 3 3 4 4 5 5 6 6 7 7];
    
fig_handle = figure;
[x,y] = treelayout(parents);
r = max(y)-y;
alpha = 2*pi*x;

x = r.*cos(alpha);
y = r.*sin(alpha);
treeplot_circular(parents);

imsizey = 1/(2^max_level) * 3; % you might want to play a bit with this multiplier
imsizex = 1/(2^max_level) * 3; % you might want to play a bit with this multiplier 
hold on

for iter = 1:2^max_level-1
    im_temp = reshape(D(:,iter),[dim_x_1,dim_x_2]);
    im = ones(dim_x_1+2,dim_x_2+2) * min(min(im_temp));
    im(2:end-1,2:end-1) = im_temp;
    h(iter) = imagesc(im);
    set(h(iter),'XData',[x(iter)- imsizex, x(iter) + imsizex]);
    set(h(iter),'YData',[y(iter)- imsizey, y(iter) + imsizey]);
end
colormap(gray);

for iter = 1:2^max_level-1
    im_temp = reshape(D(:,iter),[dim_x_1,dim_x_2]);
    im = ones(dim_x_1+2,dim_x_2+2) * min(min(im_temp));
    im(2:end-1,2:end-1) = im_temp;
    h(iter) = imshow(im,[]);
    set(h(iter),'XData',[x(iter)- imsizex, x(iter) + imsizex]);
    set(h(iter),'YData',[y(iter)- imsizey, y(iter) + imsizey]);
end
colormap(gray);

