%function [] = demo_OSDL_D_optimization()
%OSDL (Online Group-Structured Dictionary Learning) demonstration and template for D optimization.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

%clear start:
    clear all; close all;
    
%parameters:
    %dataset:
        data_type = 'ICA'; %in case of the ICA natural image datset call 'generate_X.m' first to generate to observation to OSDL.
            %size of the training image patches:
                dim_x_1 = 8;
                dim_x_2 = 8;        
            dim_x = dim_x_1 * dim_x_2;%dimension of the observation x_t-s, in case of 'ICA' dim_x equals to the patch size
    %cost:
        eta = 0.5; %\in (0,2); regularization with || ||_eta: Omega(alpha) = || (||alpha_G||_2)_G ||_eta; in case of eta \in (0,1]: the closer eta is to 0, the more 'aggressive' the sparsifications is
        kappa = 1/2^13; %>0, approximation-regularization tradeoff, the smaller kappa is the less the group structure is enforced.
                       %The obtained D dictionary depends strongly on this parameter, it is worth playing with 'kappa'.
        %G (group structure), uncomment the group structure you prefer, or define a new one in 'generate_group_structure_G.m':
            %complete binary tree:
                %G_type = 'bintree';
                %G_params.num_of_levels = 5; %Example: kappa=1/2^10
            %toroid:
                G_type = 'toroid';
                G_params.dim_alfa_y = 16;
                G_params.dim_alfa_x = 16;
                G_params.neighbor_size = 2; %Example: kappa = 1/2^13
            %block:
                %G_type = 'block';% = "non-overlapping" = "partition" = "group Lasso"
                %G_params.number_of_blocks = 5;
                %G_params.block_size = 10; %Example: kappa = 1/2^2
    %optimization:        
        method = 'BCDA'; %method of D optimization; 'BCD' (p_missing_train = 0) or 'BCDA' (p_missing_train >= 0).
        epsi = 1e-5; %smoothing constant of z to insure numerical stability, positive, <<1
        num_of_zalfa_its = 5; %number of (z,alfa) iterations
        ro = 32; %forgetting factor, >=0, "=0" = "no forgetting"
        num_of_mini_batches = 512; %number of mini-batches
        size_of_mini_batches = 64;  %size of the mini-batches (= "R")
        num_of_samples = num_of_mini_batches * size_of_mini_batches; %number of samples used for D optimization, in one epoch
        num_of_D_its = 5; %number of iterations in the BCD/BCDA (D optimization) step
        %constraints for D and alfa:
            constraint_D_id = 0; %"0" = "l_2 sphere", "1" = "non-negative l_2 sphere", "2" = "l_1 sphere", "3" = "non-negative l_1 sphere"
            constraint_alfa_id = 0; %"0" = "no constraint", "1" = "non-negativity"
        p_missing_train = 0.1;%percentage of corruption: for example, 'p_missing_train = 0.1' means that 0.1x100 = 10% of the coordinates (e.g., pixels) are missing
        epoch_interval = [1];%assumption: epoch_interval(1) = 1; for a single epoch use "[1]", for five epochs of D optimizaton write "[1:5]"

%define the group structure used (children, parents):
    [children_ct,parents_ct,children_uniform,parents_uniform,dim_alfa] = generate_group_structure_G(G_type,G_params); %children xor children_ct,parents xor parents_ct

%initialize D and the statistics of cost f:
    D = initialize_D(dim_x,dim_alfa,constraint_D_id);
    fstats = initialize_fstats(dim_x,dim_alfa,method);
    
%optimize D:    
    for epoch = epoch_interval
        %load X (and M in case of p_missing_train > 0):        
            FN = strcat('training_samples','_dimx_',num2str(dim_x_1),'x',num2str(dim_x_2),'_T',num2str(num_of_samples),'_epoch',num2str(epoch),'.mat');
            load(FN,'X');
            if p_missing_train > 0
                FN = strcat('mask','_dimx_',num2str(dim_x_1),'x',num2str(dim_x_2),'_T',num2str(num_of_samples),'_epoch',num2str(epoch),'_pm',num2str(p_missing_train),'.mat');
                load(FN,'M');
            end
        FN_suffix_train = strcat('epoch',num2str(epoch),'.mat'); %useful in case of parameter scanning
        if p_missing_train > 0
            [D,fstats] = optimize_D_with_BCDA(X,M,D,fstats,children_ct,parents_ct,children_uniform,parents_uniform,dim_alfa,eta,kappa,epsi,num_of_zalfa_its,ro,size_of_mini_batches,num_of_D_its,constraint_D_id,constraint_alfa_id,FN_suffix_train,epoch);  
        else %p_missing_train = 0
            switch method
                case 'BCD'
                    [D,fstats] = optimize_D_with_BCD(X,D,fstats,children_ct,parents_ct,children_uniform,parents_uniform,dim_alfa,eta,kappa,epsi,num_of_zalfa_its,ro,size_of_mini_batches,num_of_D_its,constraint_D_id,constraint_alfa_id,FN_suffix_train,epoch);  
                case 'BCDA'
                    [D,fstats] = optimize_D_with_BCDA(X,M,D,fstats,children_ct,parents_ct,children_uniform,parents_uniform,dim_alfa,eta,kappa,epsi,num_of_zalfa_its,ro,size_of_mini_batches,num_of_D_its,constraint_D_id,constraint_alfa_id,FN_suffix_train,epoch);                      
            end
        end
    end
    
%plot D:
    plot_D(D,G_type,G_params,dim_x_1,dim_x_2);
