function [children_ct,parents_ct,children_uniform,parents_uniform,dim_alfa] = generate_group_structure_G(G_type,G_params)
%Generates group structure given its name and parameters.
%
%Arguments:
%   G_type  : name of the group structure ('bintree', 'toroid' or 'block').
%   G_params: parameters of the group structure, see 'demo_OSDL_D_optimization.m'.
%
%Output:
%   children_ct,parents_ct,children_uniform,parents_uniform:
%      For describing the {G} group structure, we use
%      1)either the 'children_uniform' and the 'parents_uniform' integer arrays, defined as
%           children_uniform(:,j) = {i: i\in G_j},
%           parents_uniform(:,i) = {j: i\in G_j},
%        Note: in this case we implicitly assume that each group has the same number of elements 
%              [c=size(children_uniform,1)], and each element is the member of the same number of 
%              groups [p=size(parents_uniform,1)].
%      2)or the 'children_ct' and the 'parents_ct' cell arrays--in the general case--, defined as
%            children_ct{j} = {i: i\in G_j} = G_j,
%            parents_ct{i} = {j: i\in G_j}.
%        In this case length(children_ct) = number or groups, and  length(parents_ct) = dim(alpha).
%        Note: Using this convention you can define/use arbitrary group structures.
%
%      Examples:
%      In case of toroid group structure: 
%          a)nodes(=the alpha_i coordinates) are identified with groups G,
%          b)"children of node i" = "parents of node i" = "neighbors of i".
%      In case of tree group structure: 
%          a)nodes are identified with groups G.
%          b)"children of node i" = "i and its descendants",.
%          c)"parents of node i" = "i and its ascendants".
%      In case of block group structure: 
%          a)children_uniform(:,j) = G_j,
%          b)parents_uniform(:,i) = index of the groups the i^th element is member of.
%
%   dim_alfa: dimension of the hidden representation.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------


%default:
    children_ct = {};
    parents_ct = {};
    children_uniform = [];
    parents_uniform = [];
    
switch G_type
    case 'bintree'
        nodes = nodes_of_a_complete_binary_tree(G_params.num_of_levels);
        [children_ct,parents_ct] = tree_create_children_parents(nodes);
        dim_alfa = 2^(G_params.num_of_levels) - 1;
    case 'toroid'
        children_uniform = generate_toroid_alfa_neighs(G_params.dim_alfa_y,G_params.dim_alfa_x,G_params.neighbor_size);
        parents_uniform = children_uniform;
        dim_alfa = G_params.dim_alfa_y * G_params.dim_alfa_x;
    case 'block'%assumption |G_1|=|G_2|=...
        children_uniform = reshape([1:G_params.block_size * G_params.number_of_blocks],[G_params.block_size,G_params.number_of_blocks]);
        parents_uniform = kron([1:G_params.number_of_blocks],ones(1,G_params.block_size));
        dim_alfa = G_params.block_size * G_params.number_of_blocks;
    otherwise 
        disp('Error: G-type=?');
end
