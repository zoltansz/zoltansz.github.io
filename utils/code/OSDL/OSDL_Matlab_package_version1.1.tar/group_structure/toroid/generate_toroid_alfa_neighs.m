function [neighs_alfa,num_of_neighs] = generate_toroid_alfa_neighs(dim_alfa_y,dim_alfa_x,neighbor_size)
%Generates the neighbors on a toroid with given parameters.
%
%Arguments:
% size of the toroid         : dim_alfa_y x dim_alfa_x,
% neighbor size on the toroid: neighbor_size.
%
%Output:
%   neighs_alfa(:,k) : neigbors of the k^th element,
%   num_of_neighs    : number of neighbors.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

    adj_alfa = create_adj_toroid(dim_alfa_y,dim_alfa_x,neighbor_size);
    %k=1 (initialize num_of_neighs):
        nei = find(adj_alfa(:,1));
        num_of_neighs = length(nei);
        dim_alfa = dim_alfa_y * dim_alfa_x;
        neighs_alfa = zeros(num_of_neighs,dim_alfa);
        neighs_alfa(:,1) = nei;
        
    %k>1:
        for k = 2 : dim_alfa
            neighs_alfa(:,k) = find(adj_alfa(:,k));
        end
