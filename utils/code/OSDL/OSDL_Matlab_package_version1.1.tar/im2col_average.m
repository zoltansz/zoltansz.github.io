function [X_hat] = im2col_average(X_hat0,dim_x_1,dim_x_2,d1,d2)
%Computes averages over all patches intersecting the pixel points.
%
%Arguments:
%   X_hat0: estimation to average
%   size of the patches: dim_x_1 x dim_x_2
%   size of the original image: d1 x d2
%
%Output:
%   X_hat: estimation, 'averaged' version of X_hat0.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

X_hat = zeros(d1,d2);
S = zeros(d1,d2);

t = 0;
for i2 = 1 : d2- dim_x_2 + 1
for i1 = 1 : d1 - dim_x_1 + 1
    t = t + 1;
    X_hat(i1:i1+dim_x_1-1,i2:i2+dim_x_2-1) = X_hat(i1:i1+dim_x_1-1,i2:i2+dim_x_2-1)+reshape(X_hat0(:,t),dim_x_1,dim_x_2);
    S(i1:i1+dim_x_1-1,i2:i2+dim_x_2-1) = S(i1:i1+dim_x_1-1,i2:i2+dim_x_2-1) + ones(dim_x_1,dim_x_2);
end
end

X_hat = X_hat ./ S;