function [D] = initialize_D(dim_x,dim_alfa,constraint_D_id)
%Initialization of dictionary D.
%
%Arguments:
%   size of D      : 'dim_x' x 'dim_alfa',
%   constraint_D_id: constraint for dictionary D.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

switch constraint_D_id
    case 0 %l_2 sphere (||d_j||_2=1)
        D = randn(dim_x,dim_alfa);
        D = D ./ repmat(sqrt(sum(D.^2)),[dim_x 1]);
    case 1 %non-negative l_2 sphere
        D = rand(dim_x,dim_alfa);  
        D = D ./ repmat(sqrt(sum(D.^2)),[dim_x 1]);
    case 2 %l_1 sphere
        D = randn(dim_x,dim_alfa);  
        D = projection_to_the_l1_sphere_matrix(D);
    case 3 %non-negative l_1 sphere        
        D = rand(dim_x,dim_alfa);  
        D = projection_to_the_nonneg_l1_sphere_matrix(D);        
    otherwise
        disp('Error: D constraint=?');
end    
