function [] = generate_X_step1(dim_x_1,dim_x_2,image_indices)
%Generates all the 'dim_x_1' x 'dim_x_2' sized patches of the 1.tiff,...,13.tiff (the indices are given in the array 'image_indices') natural images.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

for k = image_indices
    %Xk:
        I = double(imread([num2str(k), '.tiff']))/255;
        Xk = im2col(I,[dim_x_1 dim_x_2],'sliding');
        Xk = normalize_X(Xk);
    %save Xk:
        FN = strcat('patches_in_image_',num2str(k),'_dimx_',num2str(dim_x_1),'x',num2str(dim_x_2),'.mat');
        save(FN,'Xk');
        disp(strcat(['image ',num2str(k),': processed.']));
end
    

    
