function [D,fstats] = optimize_D_with_BCDA(X,M,D,fstats,children_ct,parents_ct,children_uniform,parents_uniform,dim_alfa,eta,kappa,epsi,num_of_zalfa_its,ro,size_of_mini_batches,num_of_D_its,constraint_D_id,constraint_alfa_id,FN_suffix_train,epoch)
%D optimization using the BCDA technique.
%
%Arguments:
%   X: X(:,t) = observation at time t (x_t). 
%   M: mask for the observable coordinates of X, logical, size(X) = size(M); "M(i,j)=1" = "X(i,j) is not observable", "M(i,j)=0" = "otherwise".
%   D: initial value of the dictionary.
%   fstats: statistics of cost \hat{f}(D).
%   children_ct,parents_ct,children_uniform,parents_uniform: group structure, see also 'generate_group_structure_G.m'.
%   dim_alfa: dimension of the hidden representation alpha.
%   eta: \in (0,2); regularization with || ||_eta.
%   kappa: >0, approximation-regularization tradeoff.
%   epsi: smoothing constant of z to insure numerical stability, positive, <<1.
%   num_of_zalfa_its: number of (z,alfa) iterations.
%   ro: forgetting factor, >=0, "=0" = "no forgetting".
%   size_of_mini_batches: size of the mini-batches (= "R").
%   num_of_D_its: number of iterations in the BCD (D optimization) step.
%   constraint_D_id: constraint for D; "0" = "l_2 sphere", "1" = "non-negative l_2 sphere", "2" = "l_1 sphere", "3" = "non-negative l_1 sphere".
%   constraint_alfa_id: constraint for alpha; "0" = "no constraint", "1" = "non-negativity".
%
%assumption: 
%   size_of_mini_batches | num_of_samples, where num_of_samples = size(X,2).
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

%initialization:
    %uniform or general:
        dim_G = length(children_ct);%=|\G|, "dim_G=0" means "uniform" below
        if dim_G==0
            num_of_children = size(children_uniform,1);    
        else
            zet = zeros(dim_alfa,1);
            y = zeros(dim_G,1);
        end
    [dim_x,num_of_samples] = size(X);
    num_of_mini_batches = num_of_samples / size_of_mini_batches; %assumption: size_of_mini_batches | num_of_samples
    alfa_mini_batch = zeros(dim_alfa,size_of_mini_batches);
    %QP:
        if constraint_alfa_id == 1 %non-negativity constraint for alpha
            options = optimset('Display','off');
        end
    %statistics; can be useful to estimate iteration numbers (alpha/D optimization) or to monitor the evolution of D:
        norm_of_D_diff = zeros(num_of_mini_batches,1);
        D_old = D;
        J_zalfa = zeros(num_of_zalfa_its,num_of_mini_batches); %J(z,alpha)
        T_elapsed = 0; 
        save_D_mini_batch_num = 64;%"64" = "save the optimized D after every 64^th mini-batch"; "Inf" = "do not save"
        T_mini_batch_in_1_epoch = 0;  T_stat_in_1_epoch = 0;  T_D_in_1_epoch = 0; %elapsed time
    t = 0;
    disp('-------------------------');
    disp(strcat('epoch=',num2str(epoch)));
    disp('initialization: ready');
       
%save(D):                
    t = 0;
    if (save_D_mini_batch_num ~= Inf) & (mod(t,save_D_mini_batch_num) == 0)      
        FN  = strcat('D_tminib',num2str(t),'_',FN_suffix_train);  
        save(FN,'D');
    end
    
%optimalization:   
    for t = 1 : num_of_mini_batches
        %alfa_mini_batch:
            tic;
                X_mini_batch = X(:,(t-1)*size_of_mini_batches+1:t*size_of_mini_batches);
                M_mini_batch = M(:,(t-1)*size_of_mini_batches+1:t*size_of_mini_batches);
                Dx_mini_batch = zeros(dim_x,size_of_mini_batches);
                DeltaC = zeros(dim_x,dim_alfa);
            for t_in_mini_batch = 1 : size_of_mini_batches
                 %m,x,diadD,DTx:
                    m = M_mini_batch(:,t_in_mini_batch);%logical, "1" = "missing"
                    x = X_mini_batch(~m,t_in_mini_batch);                
                    D_temp = D(~m,:);%D at the rows corresponding to the measured x coordinates
                    diadD = D_temp.' * D_temp;
                    DTx = D_temp.' * x; %computed from measured quantities
                 %initialization of alfa based on constraint_alfa_id:
                    switch constraint_alfa_id
                        case 0 %no constraint
                            alfa = DTx; %=initialize the alpha estimation   
                        case 1 %non negative
                            alfa = ones(dim_alfa,1) / dim_alfa; %=initialize the estimation of alfa with uniform representation
                        otherwise
                            disp('Error: alfa constraint id=?');
                    end
                 %optimization of alfa:
                    for it_zalfa = 1 : num_of_zalfa_its
                        %alfa->z:
                            %alfa->y:
                                if dim_G==0%uniform
                                    if num_of_children == 1
                                        y = sqrt(sum((alfa(children_uniform).').^2,1)); %=(||alfa_G||_2)_G
                                    else
                                        y = sqrt(sum((alfa(children_uniform)).^2,1)); %=(||alfa_G||_2)_G
                                    end
                                else%general
                                    for k = 1 : dim_G
                                        y(k) = sqrt(sum(alfa(children_ct{k}).^2)); %=(||alfa_G||_2)_G
                                    end                                    
                                end
                            %y->z:    
                                z = max( (y.^(2-eta)) * sum(y.^eta)^(1-1/eta), epsi);%smoothing (numerical stability)
                        %statistics:
                            if t_in_mini_batch == size_of_mini_batches %the last one is picked from the mini-batch
                                J_zalfa(it_zalfa,t) = sum((x - D_temp*alfa).^2)/2 + kappa * sum(y.^eta)^(1/eta); %=J
                            end
                        %z->alfa:  
                            %z->zet:  
                                if dim_G==0%uniform
                                    zet = sum(1./z(parents_uniform),1);
                                else%general
                                    for k = 1 : dim_alfa
                                        zet(k) = sum(1./z(parents_ct{k}));
                                    end
                                end
                            %constraint_alfa_id -> alfa:
                                switch constraint_alfa_id
                                    case 0 %Cholesky factorization to solve the linear equation "DTx = (diadD+kappa*diag(zet)) * alfa":
                                        R = chol(diadD+kappa*diag(zet));
                                        alfa = R\(R'\DTx);
                                    case 1 %built-in QP solver for the obtained non-negative least squares problem
                                        alfa = quadprog(2*(diadD+kappa*diag(zet)),-2*DTx,[],[],[],[],zeros(dim_alfa,1),[],[],options);                                                                        
                                    otherwise
                                        disp('Error: alfa constraint id=?');
                                end
                    end
                 %store alfa to the mini-batch update of D:
                     alfa_mini_batch(:,t_in_mini_batch) = alfa;
                     Dx_mini_batch(~m,t_in_mini_batch) = x;
                     DeltaC(~m,:) = DeltaC(~m,:) + repmat((alfa.').^2,sum(~m),1);
            end
            T_mini_batch = toc; 
        %C,B update:
            tic;
                t_with_epoch = (epoch-1) * num_of_mini_batches + t;
                bet = (1-1/t_with_epoch)^(ro);
                fstats.B = bet * fstats.B + Dx_mini_batch * alfa_mini_batch.' / size_of_mini_batches;
                fstats.C = bet * fstats.C + DeltaC / size_of_mini_batches;
                fstats.E = bet * fstats.E;
            T_stat = toc;
        %D update:
            %statistics:
                D_old_temp = D;
            T_D = 0; 
            for itD = 1 : num_of_D_its
                tic;
                for jc = 1 : dim_alfa%="j"
                    alfa_mini_batch_jc = alfa_mini_batch(jc,:);
                    E_actual_jc = fstats.E(:,jc) + sum(((D * alfa_mini_batch) .* alfa_mini_batch_jc(ones(dim_x,1),:)) .* (~M_mini_batch),2) / size_of_mini_batches;
                    %"u = linsolve(diag(C(:,jc)), B(:,jc) - E_actual_jc + C(:,jc).* D(:,jc))":
                        u = (fstats.B(:,jc) - E_actual_jc) ./ fstats.C(:,jc) + D(:,jc);
                    %"d_{jc} = projection_{D_j}(u)":
                        switch constraint_D_id
                            case 0 %project to the l_2 sphere:
                                D(:,jc) = u / max(sqrt(sum(u.^2)),1);
                            case 1 %project to the non-negative l_2 sphere:
                                %project to the non-negative ortant:
                                    u = ((u>0) .* u); %u = max(u,0)
                                %project to the l_2 sphere:
                                    D(:,jc) = u / max(sqrt(sum(u.^2)),1);
                            case 2 %project to the l_1 sphere:
                                D(:,jc) = projection_to_the_l1_sphere(u);
                            case 3 %project to the non-negative l_1 sphere:
                                %D(:,jc) = projection_to_the_nonneg_l1_sphere(u);  
                                D(:,jc) = projection_to_the_l1_sphere(max(u,0));
                            otherwise
                                disp('Error: D constraint=?');
                        end
                end
                T_D = T_D + toc;
                %statistics:
                    D_old_temp = D;
            end
            tic;
                fstats.E = fstats.E + ((D*alfa_mini_batch).*(~M_mini_batch)) *  alfa_mini_batch.' / size_of_mini_batches;
            T_D = T_D + toc;
        %statistics:
            norm_of_D_diff(t) = sum(sum((D-D_old).^2)) / (dim_x*dim_alfa);
            D_old = D;
            T_elapsed = T_elapsed + (T_mini_batch+T_stat+T_D) / 3600;        
            if mod(t,100)==1 %report elapsed times at every "100"^th mini-batch
                disp(strcat('mini-batch=',num2str(t)));
                disp(strcat('->Optimization time: alpha:',num2str(T_mini_batch),', C and B:',num2str(T_stat),', D:',num2str(T_D),'s'));                
                T_total = T_elapsed / t * num_of_mini_batches; %estimation for the total optimization time in the current epoch
                disp(strcat('->Elapsed:',num2str(T_elapsed,4),', total:',num2str(T_total,4),', remaining:',num2str(T_total-T_elapsed,4),'h'));
            end
            %elapsed times:
                T_mini_batch_in_1_epoch = T_mini_batch_in_1_epoch + T_mini_batch;  
                T_stat_in_1_epoch = T_stat_in_1_epoch + T_stat;
                T_D_in_1_epoch = T_D_in_1_epoch + T_D;  
            %save(D):                
                if (save_D_mini_batch_num~=Inf) & (mod(t,save_D_mini_batch_num) == 0)            
                    FN  = strcat('D_tminib',num2str(t),'_',FN_suffix_train);                                                    
                    save(FN,'D');
                end
    end
    %save:
        FN  = strcat('summary','_',FN_suffix_train);
        save(FN,'D','fstats','norm_of_D_diff','D_old','J_zalfa',...
            'T_mini_batch_in_1_epoch','T_stat_in_1_epoch','T_D_in_1_epoch'); %elapsed times

%plot:        
    if 1        
        figure;  
            plot(norm_of_D_diff); set(gca,'YScale','log'); 
            xlabel('Number of mini-batches'); ylabel('||D_t-D_{t-1}||_F^2 / # of D coordinates');
            title(strcat('epoch:',num2str(epoch)));
        %figure;  plot(J_zalfa); xlabel('Number of (z,alfa) iterations'); ylabel('J(z,alfa)');
        %    title(strcat('epoch=',num2str(epoch)));        
    end
        