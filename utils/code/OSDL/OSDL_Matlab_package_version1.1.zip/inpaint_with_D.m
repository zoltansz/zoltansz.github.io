function [X_hat] = inpaint_with_D(X,M,D,children_ct,parents_ct,children_uniform,parents_uniform,dim_alfa,eta,kappa,epsi,num_of_zalfa_its,constraint_alfa_id)
%Inpainting using the OSDL dictionary.
%
%Arguments:
%   X: X(:,t) = observation at time t (x_t). 
%   M: mask for the observable coordinates of X, logical, size(X) = size(M); "M(i,j)=1" = "X(i,j) is not observable", "M(i,j)=0" = "otherwise".
%   D: used dictionary.
%   children_ct,parents_ct,children_uniform,parents_uniform: group structure, see also 'generate_group_structure_G.m'.
%   dim_alfa: dimension of the hidden representation.
%   eta: \in (0,2); regularization with || ||_eta.
%   kappa: >0, approximation-regularization tradeoff.
%   epsi: smoothing constant of z to insure numerical stability, positive, <<1.
%   num_of_zalfa_its: number of (z,alfa) iterations.
%   constraint_alfa_id: constraint for alpha; "0" = "no constraint", "1" = "non-negativity".
%
%Output:
%   X_hat: estimation.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

%initialization:
    %uniform or general:
        dim_G = length(children_ct);%=|\G|, "dim_G=0" means "uniform" below
        if dim_G==0
            num_of_children = size(children_uniform,1);    
        else
            zet = zeros(dim_alfa,1);
            y = zeros(dim_G,1);
        end
    [dim_x,num_of_samples] = size(X);
    alfa_mini_batch = zeros(dim_alfa,num_of_samples);
    %QP:
        if constraint_alfa_id == 1 %non-negativity constraint for alpha
            options = optimset('Display','off');
        end
    
%optimalization (=> alfa_mini_batch):   
    for t = 1 : num_of_samples
        %m,x,diadD,DTx:
            m = M(:,t);%logical, "1" = "missing"
            x = X(~m,t);                
            D_temp = D(~m,:);%D at the rows corresponding to the measured x coordinates
            diadD = D_temp.' * D_temp;
            DTx = D_temp.' * x; %computed from measured quantities
        %initialization of alfa based on constraint_alfa_id:
            switch constraint_alfa_id
                case 0 %no constraint
                    alfa = DTx; %=initialize the alpha estimation   
                case 1 %non negative
                    alfa = ones(dim_alfa,1) / dim_alfa; %=initialize the estimation of alfa with uniform representation
                otherwise
                    disp('Error: alfa constraint id=?');
            end
        %optimization of alfa:
            for it_zalfa = 1 : num_of_zalfa_its
                %alfa->z:
                    %alfa->y:
                        if dim_G==0%uniform
                            if num_of_children == 1
                                y = sqrt(sum((alfa(children_uniform).').^2,1)); %=(||alfa_G||_2)_G
                            else
                                y = sqrt(sum((alfa(children_uniform)).^2,1)); %=(||alfa_G||_2)_G
                            end
                        else%general
                            for k = 1 : dim_G
                                y(k) = sqrt(sum(alfa(children_ct{k}).^2)); %=(||alfa_G||_2)_G
                            end                                    
                        end
                    %y->z:    
                        z = max( (y.^(2-eta)) * sum(y.^eta)^(1-1/eta), epsi);%smoothing (numerical stability)
                %z->alfa:  
                    %z->zet:  
                        if dim_G==0%uniform
                            zet = sum(1./z(parents_uniform),1);
                        else%general
                            for k = 1 : dim_alfa
                                zet(k) = sum(1./z(parents_ct{k}));
                            end
                        end
                    %constraint_alfa_id -> alfa:
                        switch constraint_alfa_id
                            case 0 %Cholesky factorization to solve the linear equation "DTx = (diadD+kappa*diag(zet)) * alfa":
                                R = chol(diadD+kappa*diag(zet));
                                alfa = R\(R'\DTx);
                            case 1 %built-in QP solver for the obtained non-negative least squares problem
                                alfa = quadprog(2*(diadD+kappa*diag(zet)),-2*DTx,[],[],[],[],zeros(dim_alfa,1),[],[],options);                                                                        
                            otherwise
                                disp('Error: alfa constraint id=?');
                        end
            end
            alfa_mini_batch(:,t) = alfa;
            %disp(t):
                if mod(t,100)==1
                    disp(strcat('t=',num2str(t),'(/',num2str(num_of_samples),')'));
                end
    end
    
%estimation:
    X_hat = D * alfa_mini_batch;   
