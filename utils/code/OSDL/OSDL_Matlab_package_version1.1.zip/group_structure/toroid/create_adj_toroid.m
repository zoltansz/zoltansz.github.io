function [adj] = create_adj_toroid(dim_alfa_y, dim_alfa_x,neighbor_size)
%Creates the adjacency matrix (adj) of a toroid group structure with parameters 'dim_alfa_y', 'dim_alfa_x' and 'neighbor_size'.
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

if neighbor_size == 0 %= "G_i = {i}, for all i"
    adj = eye(dim_alfa_x*dim_alfa_y);
elseif neighbor_size == 1
    s_size = dim_alfa_y * dim_alfa_x;
    adj = spalloc(s_size,s_size,s_size*(2*neighbor_size+1)^2);
    for kx = 1 : dim_alfa_x
        for ky = 1 : dim_alfa_y
            kidx = (kx-1)*dim_alfa_y+ky;
            im = zeros(dim_alfa_y,dim_alfa_x);
            if mod(ky,2) == 0
                im(ky,mymod(kx-1:kx+1,dim_alfa_x)) = 1;
                im(mymod(ky-1,dim_alfa_y),mymod(kx-1:kx,dim_alfa_x)) = 1;
                im(mymod(ky+1,dim_alfa_y),mymod(kx-1:kx,dim_alfa_x)) = 1;
                adj(:,kidx) = im(:);
            else
                im(ky,mymod(kx-1:kx+1,dim_alfa_x)) = 1;
                im(mymod(ky-1,dim_alfa_y),mymod(kx:kx+1,dim_alfa_x)) = 1;
                im(mymod(ky+1,dim_alfa_y),mymod(kx:kx+1,dim_alfa_x)) = 1;
                adj(:,kidx) = im(:);
            end
        end
    end
    adj = full(adj);
else %for neighbor_size > 1 create the neighborship relations (topography) for neighbor_size==1, and then extend it recursively 
    [adj] = create_adj_toroid(dim_alfa_y, dim_alfa_x,1);
    for k = 2 : neighbor_size
        adj = extend_adj_toroid_by_one_level(adj);
    end
end

function r = mymod(x,m)
r = mod(x-1,m)+1;
