function [children_ct,parents_ct] = tree_create_children_parents(nodes)
%Determines the children and the parents of a tree given in 'nodes'. For the
%nodes structure, see the documentation of treeplot (doc treeplot).
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

n = size(nodes,2);

%children_ct:
    children_ct = cell(n,1);
	for i = 1 : n
		queue = [i];
		children = [];
		while length(queue) ~= 0
			current_node = queue(1);
			queue(1) = [];
			children = [children current_node];
			current_children = find(nodes == current_node);
			queue = [queue current_children];
		end
		children_ct{i} = children;
	end
    
%parents_ct:
    parents_ct = cell(n,1);
	for i = 1 : n
		looked = i;
		parents = [];
		while looked ~= 0
			parents = [looked parents];
			index = nodes(looked);
			looked = index;
		end
		parents_ct{i} = parents;
	end

