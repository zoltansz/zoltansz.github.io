function [] = plot_D(D,G_type,G_params,dim_x_1,dim_x_2)
%Illustrates dictionary D for group structure G_type with parameters G_params.
%
%Other arguments:
%   D: dictionary,
%   size of the d_j columns of D: dim_x_1 x dim_x_2
%----------------------
%Copyright (C) 2012 Zoltan Szabo (szzoli@cs.elte.hu)
%
%This file is part of the OSDL (Online Group-Structured Dictionary Learning) Matlab toolbox.
%
%OSDL is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by
%the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
%
%This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
%MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
%
%You should have received a copy of the GNU General Public License along with OSDL. If not, see <http://www.gnu.org/licenses/>.
%---------------------

switch G_type
    case 'toroid'
        offset =  floor(dim_x_2/2);%imitiate toroid by shifting every second row
        size_of_edge = 0;
        plot_D_toroid(D,G_params.dim_alfa_y,G_params.dim_alfa_x,dim_x_1,dim_x_2,offset,size_of_edge);
    case 'block'
        offset = 0;%do not imitiate, we are not on a toroid  
        size_of_edge = 0;        
        plot_D_toroid(D,G_params.block_size,G_params.number_of_blocks,dim_x_1,dim_x_2,offset,size_of_edge);%one column in the figure corresponds to one group
    case 'bintree'
        max_level = G_params.num_of_levels;
        plot_D_treeplot(D,dim_x_1,dim_x_2,max_level);
    otherwise
        disp(strcat('There is no drawing function associated to group structure: ',G_type));
end